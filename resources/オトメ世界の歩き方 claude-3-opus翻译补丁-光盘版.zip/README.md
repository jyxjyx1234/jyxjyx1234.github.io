本补丁由ALyCE\jyxjyx1234制作，使用claude-3-oups进行翻译。

本补丁免费发布于2dfan\github。如果从 网赚盘（如飞猫云） or 付费 下载到本补丁，请顺手点个举报。

2dfan主页：[https://2dfan.com/users/290175](https://2dfan.com/users/290175)
github主页：[https://github.com/jyxjyx1234](https://github.com/jyxjyx1234)
个人博客：[https://jyxjyx1234.github.io/](https://jyxjyx1234.github.io/)（包含本人制作的所有补丁）

# 使用方法

将补丁中的内容覆盖到游戏目录。无需转区。

如果启动不成功请先尝试安装 https://aka.ms/vs/17/release/vc_redist.x86.exe 后重启。
