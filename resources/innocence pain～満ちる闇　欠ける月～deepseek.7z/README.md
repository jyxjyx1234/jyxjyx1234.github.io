本补丁由ALyCE\jyxjyx1234制作，使用deepseek进行翻译。

本补丁免费发布，首发2dfan及github，禁止任何形式的收费转载。如果从 网赚盘（如飞猫云）、付费群、付费网站 下载到本补丁，请顺手点个举报。

如果补丁运行遇到问题，可在2dfan评论区留言或发邮件至jyxjyx1234@outlook.com。

2dfan主页：[https://2dfan.com/users/290175](https://2dfan.com/users/290175)
github主页：[https://github.com/jyxjyx1234](https://github.com/jyxjyx1234)
个人博客：[https://jyxjyx1234.github.io/](https://jyxjyx1234.github.io/)（包含本人制作的所有补丁）

通过RSS订阅以下链接，获取补丁发布/更新通知：https://jyxjyx1234.github.io/feed.xml

# 使用方法

！！不要有中文路径！！
！！不要有中文路径！！
！！不要有中文路径！！

将补丁中的内容覆盖到游戏目录，从innocence pain_chs.exe启动。已实现免DVD。无需转区。请勿安装字体。(但部分win11下可能得安装字体，如果遇到文字乱码请先尝试安装。)

游戏内可以更改主角姓名，但是本补丁没有适配，请使用默认姓名。更改姓名不会生效，还可能引入未知bug。

如果启动不成功请先尝试安装 https://aka.ms/vs/17/release/vc_redist.x86.exe 后重启。
